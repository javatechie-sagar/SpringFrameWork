package com.mycom.springcore.autowired.collection;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration
@ComponentScan("com.mycom.springcore.autowired.collection")
public class AppConfig {

    @Bean
    public Account accountSavings() {
        return new Account(101, "Savings", 150000);
    } 
    @Bean
    public Account accountFD() {
        return new Account(102, "Fixed Deposit", 500000);
    }
    @Bean
    public Account accountRD() {
        return new Account(103, "Recurring Deposit", 300000);
    }
    
    @Bean
    public AccountService accountService() {
        return new AccountService();
    }

   
}
