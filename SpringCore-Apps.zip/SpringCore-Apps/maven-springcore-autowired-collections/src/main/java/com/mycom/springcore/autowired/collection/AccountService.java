package com.mycom.springcore.autowired.collection;
 	
import org.springframework.beans.factory.annotation.Autowired;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

public class AccountService {

    @Autowired   // above field
    private List<Account> accountList;

    public void displayAccounts() {
        for (Account account : accountList) {
            System.out.println(account); // toString() method of Account class automatically
        }
    }
}