package com.mycom.springcore.singleton;
public class Student {
	public Student() {
        System.out.println("Student object created");
    }
}
