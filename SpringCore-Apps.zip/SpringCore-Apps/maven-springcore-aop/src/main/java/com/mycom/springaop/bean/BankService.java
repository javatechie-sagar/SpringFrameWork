package com.mycom.springaop.bean;

public class BankService {

    public void withdraw() {
        System.out.println("Withdraw money logic");
    }

    public void deposit() {
        System.out.println("Deposit money logic");
    }
}
