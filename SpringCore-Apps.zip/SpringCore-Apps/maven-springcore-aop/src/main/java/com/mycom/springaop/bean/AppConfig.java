package com.mycom.springaop.bean;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.EnableAspectJAutoProxy;

import com.mycom.springaop.aspect.LoggingAspect;

@Configuration
@EnableAspectJAutoProxy   // Enables AOP support
public class AppConfig {

    @Bean
    public BankService bankService() {
        return new BankService();
    }

    @Bean
    public LoggingAspect loggingAspect() {
        return new LoggingAspect();
    }
}
