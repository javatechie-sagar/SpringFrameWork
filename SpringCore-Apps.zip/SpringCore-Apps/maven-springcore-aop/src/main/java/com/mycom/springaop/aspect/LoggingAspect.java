package com.mycom.springaop.aspect;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
@Aspect
public class LoggingAspect {
    @Around("execution(* com.mycom.springaop.bean.BankService.*(..))")
    public Object logExecution(ProceedingJoinPoint joinPoint) throws Throwable {
        System.out.println("LOG: Method started :  " +
        joinPoint.getSignature().getName());
        Object result = joinPoint.proceed(); // call actual method
        System.out.println("LOG: Method ended :  " +
         joinPoint.getSignature().getName());
        return result;
    }
}
