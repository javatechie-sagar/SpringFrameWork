import org.springframework.expression.Expression;
import org.springframework.expression.ExpressionParser;
import org.springframework.expression.spel.standard.SpelExpressionParser;
import org.springframework.expression.spel.support.StandardEvaluationContext;

public class MainSpELApp{
    public static void main(String[] args) {

        Customer customer = new Customer("Anoohya", 25);

        ExpressionParser parser = new SpelExpressionParser();
        StandardEvaluationContext context =
                new StandardEvaluationContext(customer);

        Expression exp1 = parser.parseExpression("name");
        Expression exp2 = parser.parseExpression("age > 18");

        String name = exp1.getValue(context, String.class);
        Boolean isVoter = exp2.getValue(context, Boolean.class);

        System.out.println("Name: " + name);
        System.out.println("Is a voter : " + isVoter);
    }
}
