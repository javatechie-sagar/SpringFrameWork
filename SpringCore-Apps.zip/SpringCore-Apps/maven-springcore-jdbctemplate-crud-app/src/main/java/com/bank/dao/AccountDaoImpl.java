package com.bank.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.BeanPropertySqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;
//import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;

import com.bank.model.Account;

//DAO layer
@Repository
public class AccountDaoImpl implements IAccountDao {
	// Injects JdbcTemplate
	@Autowired
	private JdbcTemplate jdbcTemplate;
//    @Autowired
//    private NamedParameterJdbcTemplate nptemplate;
	@Override
	public void save(Account account) {
		String sql = "INSERT INTO account VALUES (?, ?, ?)";
		jdbcTemplate.update(sql, account.getId(), account.getName(), 
				account.getBalance());
	}
	@Override
	public Account findById(int id) { 
		// returns account row and maps to Account object
		String sql = "SELECT * FROM account WHERE id = ?";
		return jdbcTemplate.queryForObject(sql, 
				new BeanPropertyRowMapper<>(Account.class), id);
	}
	
	@Override
	public List<Account> findAll() {
		String sql = "SELECT * FROM account";
		// BeanPropertyRowMapper → Automatic mapping of all rows to List collection
		// Avoiding individual account bean addition to accountList collection
		List<Account> accountList = 
		  jdbcTemplate.query(sql, new BeanPropertyRowMapper<>(Account.class));
		return accountList;
	}
	// UPDATE
	@Override
	public void update(Account account) {
		String sql = "UPDATE account SET name = ?, balance = ? WHERE id = ?";
		jdbcTemplate.update(sql, account.getName(), 
				account.getBalance(), account.getId());
	}
	// DELETE
	@Override
	public void delete(int id) {
		String sql = "DELETE FROM account WHERE id = ?";
		jdbcTemplate.update(sql, id);
	}
	
	//NamedParameterJdbcTemplate
	
	  @Autowired
	    private NamedParameterJdbcTemplate nptemplate;

	    // =========================
	    // 1. INSERT
	    // =========================
	    public void addAccount(Account account) {
	        String sql = "INSERT INTO account (id, name, balance) " +
	                     "VALUES (:id, :name, :balance)";
	        BeanPropertySqlParameterSource params =
	                new BeanPropertySqlParameterSource(account);
	        nptemplate.update(sql, params);
            System.out.println("Account Inserted Successfully using named params!");
	    }
}



