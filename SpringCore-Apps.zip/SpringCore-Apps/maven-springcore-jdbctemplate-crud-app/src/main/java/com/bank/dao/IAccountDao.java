package com.bank.dao;

import java.util.List;
import com.bank.model.Account;

public interface IAccountDao {

	//Design CRUD operations - not implemention
    void save(Account account);        // CREATE
    
    Account findById(int id);           		// READ
    
    List<Account> findAll();            		// READ ALL
    
    void update(Account account);     // UPDATE
    
    void delete(int id);              			// DELETE
    
    void addAccount(Account acc);// For named parameters
}