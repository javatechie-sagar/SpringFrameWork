package com.bank.client;

import java.util.List;
import java.util.Scanner;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.bank.config.JdbcConfig;
import com.bank.dao.AccountDaoImpl;
//import com.bank.dao.AccountDaoNamedParameterJdbcTemplate;
import com.bank.dao.IAccountDao;
import com.bank.model.Account;

public class MainApp {

	public static void main(String[] args) {

		ApplicationContext context = 
				new AnnotationConfigApplicationContext(JdbcConfig.class);
		
		IAccountDao dao = context.getBean(AccountDaoImpl.class);

		Scanner sc = new Scanner(System.in);
		int choice;

		do {
			System.out.println("\n===== MENU =====");
			System.out.println("1. Add Account");
			System.out.println("2. Show All Accounts");
			System.out.println("3. Update Account");
			System.out.println("4. Delete Account");
			System.out.println("5. Exit");
			System.out.print("Enter choice: ");
	
			choice = sc.nextInt();

			switch (choice) {

			case 1:
				System.out.print("Enter ID: ");
				int id = sc.nextInt();
				sc.nextLine();
				System.out.print("Enter Name: ");
				String name = sc.nextLine();
				System.out.print("Enter Balance: ");
				double balance = sc.nextDouble();
				dao.save(new Account(id, name, balance));
				break;
				
			case 2:
				List<Account> accounts = dao.findAll();
				accounts.forEach(System.out::println);// method reference
				break;

			case 3:
				System.out.print("Enter ID to Update: ");
				int uid = sc.nextInt();
				sc.nextLine();

				System.out.print("Enter New Name: ");
				String uname = sc.nextLine();

				System.out.print("Enter New Balance: ");
				double ubalance = sc.nextDouble();

				dao.update(new Account(uid, uname, ubalance));
				break;

			case 4:
				System.out.print("Enter ID to Delete: ");
				int did = sc.nextInt();
				dao.delete(did);
				
				break;

			case 5:
				System.out.println("Exiting...");
				System.out.println("Thank you for using our app...");
				break;

			default:
				System.out.println("Invalid Choice!");
				
			}

		} while (choice != 5);

		sc.close();
		
		System.out.println("Named Parameter Bean!");
        Account acc = new Account(3, "Sagar", 5000);
        dao.addAccount(acc);

        System.out.println("Operations Completed Successfully!");
		
	}
}