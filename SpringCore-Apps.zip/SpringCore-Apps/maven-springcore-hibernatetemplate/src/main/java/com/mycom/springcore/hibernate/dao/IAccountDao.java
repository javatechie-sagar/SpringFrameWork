package com.mycom.springcore.hibernate.dao;

import java.util.List;

import com.mycom.springcore.hibernate.beans.Account;

public interface IAccountDao {
    void save(Account account);
    
    Account findById(int id);
    
    List<Account> findAll();
    
    void update(Account account);
    
    void delete(int id);
}
