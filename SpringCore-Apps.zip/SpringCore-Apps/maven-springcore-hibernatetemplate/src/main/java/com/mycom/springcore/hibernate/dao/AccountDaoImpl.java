package com.mycom.springcore.hibernate.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate5.HibernateTemplate;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.mycom.springcore.hibernate.beans.Account;

// Repository - synonym for database or persistence
@Repository
// Transactional -  Allows DB transactional - INSERT, UPDATE, DELETE
@Transactional
public class AccountDaoImpl implements IAccountDao{
	  @Autowired
	    private HibernateTemplate hibernateTemplate;
	    @Override
	    public void save(Account account) {
	        hibernateTemplate.save(account);
	    }
	    @Override
	    public Account findById(int id) {
	        return hibernateTemplate.get(Account.class, id);
	    }
	    @Override
	    public List<Account> findAll() {
	        return hibernateTemplate.loadAll(Account.class);
	    }
	    @Override
	    public void update(Account account) {
	        hibernateTemplate.update(account);
	    }
	    @Override
	    public void delete(int id) {
	        Account acc = hibernateTemplate.get(Account.class, id);
	        if (acc != null) {
	            hibernateTemplate.delete(acc);
	        }
	}

}
