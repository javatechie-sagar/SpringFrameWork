package com.mycom.springcore.hibernate.service;

import java.util.List;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.mycom.springcore.hibernate.beans.Account;
import com.mycom.springcore.hibernate.config.HibernateConfig;
import com.mycom.springcore.hibernate.dao.IAccountDao;

public class ClientApp {
	public static void main(String[] args) {
		AnnotationConfigApplicationContext ctx =
				new AnnotationConfigApplicationContext(HibernateConfig.class);
		IAccountDao accountDao = (IAccountDao) ctx.getBean(IAccountDao.class);
		Account account = new Account();
		account.setId(101);
		account.setName("Manyatha");
		account.setBalance(75000);
		accountDao.save(account);
		account = null;
		account = new Account();
		account.setId(102);
		account.setName("Nesha");
		account.setBalance(60000);
		accountDao.save(account);
		ctx.close();
		
		
		
		
		
//		account.setId(103);
//		account.setName("Nesha");
//		account.setBalance(60000);
//		accountDao.save(account);

//      account = accountDao.findById(101);
//       System.out.println(account.getName() + " " + 
//    		   			account.getBalance());

		List<Account> accountList = accountDao.findAll();
		for (Account account2 : accountList) {
			System.out.println(account2);
		}

//		account = accountDao.findById(104);
//		System.out.println("Account Data before update : " + account);
//		account.setBalance(100000);
//		accountDao.update(account);
//		System.out.println("Account Data after update : " + account);

//		account= accountDao.findById(102);
//    	accountDao.delete(102);
//		System.out.println("Account Data after deletion : ");
//		accountList = accountDao.findAll();
//		for (Account account2 : accountList) {
//			System.out.println(account2);
//		}
		ctx.close();
	}
}
