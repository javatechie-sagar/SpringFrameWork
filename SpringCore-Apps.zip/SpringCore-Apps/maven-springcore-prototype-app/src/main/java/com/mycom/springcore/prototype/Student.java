package com.mycom.springcore.prototype;
public class Student {
	public Student() {
        System.out.println("Student object created");
    }
}
