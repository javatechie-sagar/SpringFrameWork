package com.mycom.springcore.constructorinjection;
public class Customer {

    private Account account;

    // Constructor injection
    public Customer(Account account) {
        this.account = account;
    }

    public void display() {
        System.out.println(
            "Account No: " + account.getAccountNumber() +
            ", Balance: " + account.getBalance()
        );
    }
}
