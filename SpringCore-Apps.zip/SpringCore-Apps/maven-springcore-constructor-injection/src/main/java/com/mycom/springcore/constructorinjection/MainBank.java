 package com.mycom.springcore.constructorinjection;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class MainBank {
	public static void main(String[] args) {
		ApplicationContext context =
			    new ClassPathXmlApplicationContext("applicationContext.xml");

			Customer c1 = context.getBean("customer", Customer.class);
			c1.display();

			Customer c2 = context.getBean("customer2", Customer.class);
			c2.display();

	}
}
