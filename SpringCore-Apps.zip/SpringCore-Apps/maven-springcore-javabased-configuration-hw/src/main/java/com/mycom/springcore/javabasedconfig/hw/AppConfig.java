package com.mycom.springcore.javabasedconfig.hw;
import org.springframework.beans.factory.config.ConfigurableBeanFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Scope;
 

public class AppConfig {
   @Bean    
//   @Scope(value = ConfigurableBeanFactory.SCOPE_SINGLETON)	
   @Scope(value = ConfigurableBeanFactory.SCOPE_PROTOTYPE)
   //One object per container (default)
   
   public HelloWorld helloWorld(){
      return new HelloWorld();
   }
}





