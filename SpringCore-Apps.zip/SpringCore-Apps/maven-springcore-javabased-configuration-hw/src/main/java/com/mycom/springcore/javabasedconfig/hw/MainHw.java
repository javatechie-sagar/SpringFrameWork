package com.mycom.springcore.javabasedconfig.hw;

import org.springframework.context.ApplicationContext;
//import org.springframework.context.annotation.*;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class MainHw {
	public static void main(String[] args) {
		ApplicationContext ctx = 
				new AnnotationConfigApplicationContext(AppConfig.class);

		HelloWorld helloWorld = ctx.getBean(HelloWorld.class);
		helloWorld.setMessage("Hello World!");
		helloWorld.getMessage();

		HelloWorld helloWorld2 = ctx.getBean(HelloWorld.class);
		helloWorld2.setMessage("Hi World!");	
		helloWorld2.getMessage();
		System.out.println("Hash Codes - " + helloWorld.hashCode() + "    " 
										+ helloWorld2.hashCode());
		
	}
}