package com.mycom.springcore.javabasedconfig.hw;

public class HelloWorld { // Dependent bean
   private String message;//Dependency bean
   
   // Dependency using setter injection
   public void setMessage(String message){
      this.message  = message;
   }
   public void getMessage(){
      System.out.println("Your Message : " + message);
   }
}
