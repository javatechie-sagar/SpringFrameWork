package com.mycom.springcore.autowired.annotation.bean;



import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class AppConfig {

    @Bean
    public Account account() {
        return new Account(101, "Savings", 50000);
    }

    @Bean
    public Customer customer() { 
        return new Customer(1, "Vismya"); // Account bean is injected thru setter, hence no reference for Account
    }
}
