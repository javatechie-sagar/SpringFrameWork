package com.mycom.springcore.autowired.annotation.bean;

import org.springframework.beans.factory.annotation.Autowired;

public class Customer {

    private int customerId;
    private String customerName;

    //@Autowired
    //private Account account;   // Field Injection

    public Customer(int customerId, String customerName) {
        this.customerId = customerId;
        this.customerName = customerName;
    }
    
      
     private Account account;
	/*
		 * // Constructor Injection
		 * 
		 * @Autowired public Customer(Account account) { this.account = account; }
		 */
  
    
    @Autowired // setter injection
    public void setAccount(Account account) {
        this.account = account;
    }

    public void displayCustomer() {
        System.out.println("Customer Id: " + customerId);
        System.out.println("Customer Name: " + customerName);
        account.displayAccount();
    }
}
