package com.mycom.springcore.autowired.annotation.bean;

public class Account {

    private int accountNumber;
    private String accountType;
    private double balance;

    public Account(int accountNumber, String accountType, double balance) {
        this.accountNumber = accountNumber;
        this.accountType = accountType;
        this.balance = balance;
    }

    public void displayAccount() {
        System.out.println("Account No: " + accountNumber);
        System.out.println("Account Type: " + accountType);
        System.out.println("Balance: " + balance);
    }
}
