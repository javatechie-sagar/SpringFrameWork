package com.mycom.springcore.setterinjection.beans;
import org.springframework.beans.factory.config.ConfigurableBeanFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Scope;


public class AppConfig {
   @Bean    
   @Scope(value = ConfigurableBeanFactory.SCOPE_SINGLETON)	
   public Address address(){
      return new Address(101,"Signature Casle","Krishna Nagar", "Pune");
   }
   @Bean  
   public Employee employee(){
	      return new Employee(1111,"Anoohya");
	   }
}







