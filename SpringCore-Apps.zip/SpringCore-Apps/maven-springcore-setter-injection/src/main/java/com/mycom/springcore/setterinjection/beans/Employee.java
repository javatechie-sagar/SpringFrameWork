package com.mycom.springcore.setterinjection.beans;

import org.springframework.beans.factory.annotation.Autowired;

public class Employee {
	int id;
	String name;
	Address address;
	
	public int getId(){
		return id;
	}
	public Employee(int id, String name) {
		super();
		this.id = id;
		this.name = name;
		
	}
	public String getName() {
		return name;
	}
	
	public Address getAddress() {
		return address;
		
	}
	@Autowired
	public void setAddress(Address address) {
		this.address = address;
		
	}
	public void setId(int id) {
		this.id = id;
	}
	public void setName(String name) {
		this.name = name;
	}
	
}
