package com.mycom.springcore.setterinjection.main;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.mycom.springcore.setterinjection.beans.AppConfig;
import com.mycom.springcore.setterinjection.beans.Employee;
public class MainEmployee {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ApplicationContext context = 
				new AnnotationConfigApplicationContext(AppConfig.class);
		Employee emp = (Employee) context.getBean("employee");
		 System.out.println("Employee data");	
		System.out.println( emp.getId() + "-- " + emp.getName());
	    System.out.println("\nAddress of employee");
			    
		System.out.println("Flat No : " + emp.getAddress().getFlatno() );
		System.out.println("Appartment Name : " + emp.getAddress().getAppartmentName() );
		System.out.println("Area : " + emp.getAddress().getArea() );
		System.out.println("City : " + emp.getAddress().getCity() );
		
	}
}
	