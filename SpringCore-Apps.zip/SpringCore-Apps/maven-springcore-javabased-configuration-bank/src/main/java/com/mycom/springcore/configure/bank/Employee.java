package com.mycom.springcore.configure.bank;

public interface Employee {
		void doWork();

}