package com.mycom.springcore.configure.bank;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import  com.mycom.springcore.configure.bank.*;

@Configuration
public class AppConfig {
   @Bean 
   public Accountant accountant(){
      return new Accountant();
   }
   @Bean 
   public Manager manager(){
      return new Manager();
   }
}