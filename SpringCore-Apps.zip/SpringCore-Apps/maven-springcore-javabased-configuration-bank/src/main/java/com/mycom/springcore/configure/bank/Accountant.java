package com.mycom.springcore.configure.bank;

public class Accountant implements Employee{
	
	public void doWork() {
				System.out.println("Accountant audits the accounts...");
	}
}