package com.mycom.springcore.configure.bank;

public class Manager implements Employee{
	
	public void doWork() {
		
		System.out.println("Manager manages the branch office");
	}
}