package com.mycom.springcore.configure.bank;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class BankApp {
	public static void main(String[] args) {
		ApplicationContext context = new AnnotationConfigApplicationContext(AppConfig.class);
		Employee accountant = (Employee) context.getBean("accountant");
		accountant.doWork();
		Employee manager = (Employee) context.getBean("manager");
		manager.doWork();
	}

}