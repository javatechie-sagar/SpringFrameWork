package com.mycom.springcore.spel.operators.methods;

import java.text.ParseException;
import java.util.Arrays;
import java.util.List;

import org.springframework.expression.Expression;
import org.springframework.expression.ExpressionParser;
import org.springframework.expression.spel.standard.SpelExpressionParser;

public class MainApp {
	public static void main(String[] args) throws ParseException {
		ExpressionParser parser = new SpelExpressionParser();

		// evaluates to 5
		int result = parser.parseExpression("3 + 2").getValue(Integer.class);
		System.out.println("Sum : " + result);

		// evaluates to 1
		result = parser.parseExpression("3 - 2").getValue(Integer.class);
		System.out.println("Difference : " + result);
		

		// evaluates to 6
		result = parser.parseExpression("3 * 2").getValue(Integer.class);
		System.out.println("Product : " + result);

		// evaluates to 1
		result = parser.parseExpression("3 / 2").getValue(Integer.class);
		System.out.println("Quotient : " + result);

		// evaluates to 1
		result = parser.parseExpression("3 % 2").getValue(Integer.class);
		System.out.println("Reminder : " + result);

		// follow operator precedence, evaluate to -9
		int exprResult = parser.parseExpression("1+2-3*4").getValue(Integer.class);
		System.out.println("Expression evaluation : " + exprResult);
		/*-----------------------------------*/
		System.out.println("Relational Operators");
		// evaluates to true
		boolean equalResult = parser.parseExpression("2 == 2").getValue(Boolean.class);
		System.out.println("2==2 :" + equalResult);

		// evaluates to false
		boolean ltResult = parser.parseExpression("2 < -5.0").getValue(Boolean.class);
		System.out.println("2 < -5.0 : " + ltResult);
		
		// evaluates to true
		boolean strResult = 
				parser.parseExpression("'black' < 'block'").getValue(Boolean.class);
		System.out.println("'black' < 'block' : " + strResult);

		// evaluates to false - regular expression
		boolean regExResult = 
				parser.parseExpression("'5.0067' matches '^-?\\d+(\\.\\d{2})?$'")
				          .getValue(Boolean.class);
		System.out.println(" 5.0067 matches : " + regExResult);
		
		System.out.println("Logical Operators");

		// evaluates to true returns true
		boolean boolResult = parser.parseExpression("true and true")
													   .getValue(Boolean.class);
		System.out.println("true and true : " + boolResult);
		
		
		
		

		// evaluates to false
		boolResult = parser.parseExpression("true and false")
				                        .getValue(Boolean.class);
		System.out.println("true and false : " + boolResult);

		// evaluates to false
		boolResult = parser.parseExpression("!true").getValue(Boolean.class);
		System.out.println("!true : " + boolResult);

		// Using Calculator object
		

		Calculator calculator = new Calculator();
		ExpressionParser expParser = new SpelExpressionParser();
		Expression expression = parser.parseExpression("add(10, 20)");
		int sum = (int) expression.getValue(calculator);
		System.out.println("Sum = "  + sum); // Output: 30
		
		
		// Using Collection
		// Arrays.asList() - converts an array of objects into List object
		List<Person> people = Arrays.asList(
			    new Person("Nischala", 30),
			    new Person("Ayan", 25),
			    new Person("Anoohya", 40)
			);

			ExpressionParser exprParser = new SpelExpressionParser();
			Expression expr = parser.parseExpression("?[age > 30]");
			List listResult = (List) expr.getValue(people);
			System.out.println(listResult); 

			// String manipulatlion
			
			ExpressionParser strParser = new SpelExpressionParser();
			Expression exp = strParser.parseExpression("'Hello World'.concat('!')");
			String msg = (String) exp.getValue();
			
			System.out.println("Message - concat() "  + msg);
			
			exp = parser.parseExpression("new String('hello world').toUpperCase()");
			String upperMsg = exp.getValue(String.class);	
			
			System.out.println("Message - toUpper() "  + upperMsg);
						
	}
}