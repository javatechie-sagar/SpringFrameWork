package com.mycom.controller;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class CountryController {
	 //@RequestMapping(value="/str/{countryName}/{userName}", method=RequestMethod.GET) 
	 @RequestMapping("/strname/{userName}")
	    
	 public ModelAndView getStringData(@PathVariable(value="userName") String userName) {
	 
	        ModelAndView mav = new ModelAndView();
	        mav.addObject("msg", "Name :  " + userName);
	        mav.setViewName("success");
	        return mav;
	    }
}
